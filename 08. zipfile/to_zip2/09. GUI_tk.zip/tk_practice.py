from tkinter import *

window = Tk()
window.geometry('100x100')
b1 = Button(window, text = 'Run')
b1.grid(row=0, column=0)

window.mainloop()
